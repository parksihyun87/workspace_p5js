<<sketch.js list>> : 내용 (클릭시 노래)
1. 소리 반응 원형 파장과 입자 (everglow)
2. 사인,코사인 벨벳 형태 사각형 움직임 (HolyForever)
3. 감각적인 원형 테두리 움직임 (HoveringThoughts)/(소리따라 모양 반향 파일을 주석처리 저장)
4. 파형 3d 입체의 파고 변형 (MoonlightNightMagic)
5. 원형체의 주기적 랜덤 모형 변형 (Recollection)
6. 플로우 필드의 색 변화(theThoughtsofYou/RhythmChanges/Wander)

